package tests;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import org.testng.reporters.jq.INavigatorPanel;
import pages.*;

import static helpers.Utilities.getPropertyFromAppProp;

public class CreateAccountTest extends BaseTest {
    final static String INVALID_EMAIL_ERROR = "Invalid email address.";

    private DashboardPage dashboardPage = null;
    private CreateAccountPage createAccountPage = null;
    private RegisterAccountPage registerAccountPage = null;
    private MyAccountPage myAccountPage = null;

    private String customerFirstName;
    private String customerLastName;
    private String emailNew;
    private String passwordNew;
//    private String day;
//    private String month;
//    private String year;
    private String firstName;
    private String lastName;
    private String company;
    private String address1;
    private String address2;
    private String city;
//    private String state;
    private String postalCode;
    private String country;
    private String additionalInfo;
    private String phone;
    private String mobilePhone;
    private String alias;

    public CreateAccountTest() {
        this.customerFirstName = getPropertyFromAppProp("customerFirstName");
        this.customerLastName = getPropertyFromAppProp("customerLastName");
        this.emailNew = getPropertyFromAppProp("emailNew");
        this.passwordNew = getPropertyFromAppProp("passwordNew");
//        this.day = Integer.parseInt(getPropertyFromAppProp("day"));
//        this.month = Integer.parseInt(getPropertyFromAppProp("month"));
//        this.year = Integer.parseInt(getPropertyFromAppProp("year"));
        this.firstName = getPropertyFromAppProp("firstName");
        this.lastName = getPropertyFromAppProp("lastName");
        this.company = getPropertyFromAppProp("company");
        this.address1 = getPropertyFromAppProp("address1");
        this.address2 = getPropertyFromAppProp("address2");
        this.city = getPropertyFromAppProp("city");
//        this.state = getPropertyFromAppProp("state");
        this.postalCode = getPropertyFromAppProp("postalCode");
        this.country = getPropertyFromAppProp("country");
        this.additionalInfo = getPropertyFromAppProp("additionalInfo");
        this.phone = getPropertyFromAppProp("phone");
        this.mobilePhone = getPropertyFromAppProp("mobilePhone");
        this.alias = getPropertyFromAppProp("alias");
    }

    @BeforeMethod
    void beforeMethod() {
        this.dashboardPage = new DashboardPage(getDriver());
        this.createAccountPage = new CreateAccountPage(getDriver());
        this.registerAccountPage = new RegisterAccountPage(getDriver());
        this.myAccountPage = new MyAccountPage(getDriver());
    }

    @Test
    public void testEmptyEmail() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.createAccountPage.verify();
        this.createAccountPage.create("");

        this.createAccountPage.verify();
    //    Assert.assertTrue(this.createAccountPage.checkError());
        Assert.assertEquals(this.createAccountPage.checkError(), INVALID_EMAIL_ERROR);
    }

    @Test
    public void testInvalidEmail() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.createAccountPage.verify();
        this.createAccountPage.create(getPropertyFromAppProp("invalidEmail"));

        this.createAccountPage.verify();
  //      Assert.assertTrue(this.createAccountPage.checkError());
        Assert.assertEquals(this.createAccountPage.checkError(), INVALID_EMAIL_ERROR);
    }

    @Test
    public void testCreateAccount() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.createAccountPage.verify();
        this.createAccountPage.create(emailNew);

        this.registerAccountPage.verify();

        this.registerAccountPage.register();
        //customerFirstName, customerLastName, passwordNew, day, month, year, firstName,
        //                lastName, company, address1, address2, city, state, postalCode, country, additionalInfo, phone, mobilePhone,
        //                alias

        this.myAccountPage.verify();
    }


}
