package tests;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.DashboardPage;
import pages.LoginPage;
import pages.MyAccountPage;

import static helpers.Utilities.getPropertyFromAppProp;

public class LoginTest extends BaseTest {
    final static String EMPTY_CREDENTIALS_ERROR = "An email address required.";
    final static String EMPTY_PSW_ERROR = "Password is required.";
    final static String INVALID_EMAIL_ERROR = "Invalid email address.";
    final static String INVALID_CREDENTIALS_ERROR = "Authentication failed.";

    private DashboardPage dashboardPage = null;
    private LoginPage loginPage = null;
    private MyAccountPage myAccountPage = null;

    private String email;
    private String password;
    private String emailInvalidFormat;
    private String emailInvalid;
    private String pswInvalid;

    public LoginTest() {
        this.email = getPropertyFromAppProp("email");
        this.password = getPropertyFromAppProp("password");
        this.emailInvalid = getPropertyFromAppProp("invalidEmail");
        this.emailInvalidFormat = getPropertyFromAppProp("invalidEmailFormat");
        this.pswInvalid = getPropertyFromAppProp("invalidPsw");
    }

    @BeforeMethod
    void beforeMethod() {
        this.dashboardPage = new DashboardPage(getDriver());
        this.loginPage = new LoginPage(getDriver());
        this.myAccountPage = new MyAccountPage(getDriver());
    }

    @Test
    public void testEmptyCredentials() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.loginPage.verify();
        this.loginPage.login("", "");

        this.loginPage.verify();
    //    Assert.assertTrue(this.loginPage.viewError().isDisplayed());
        Assert.assertEquals(this.loginPage.viewError(),EMPTY_CREDENTIALS_ERROR);
    }

    @Test
    public void testEmptyEmail() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.loginPage.verify();
        this.loginPage.login("", password);

        this.loginPage.verify();
   //     Assert.assertTrue(this.loginPage.viewError().isDisplayed());
        Assert.assertEquals(this.loginPage.viewError(),EMPTY_CREDENTIALS_ERROR);
    }

    @Test
    public void testEmptyPassword() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.loginPage.verify();
        this.loginPage.login(email, "");

        this.loginPage.verify();
    //    Assert.assertTrue(this.loginPage.viewError().isDisplayed());
        Assert.assertEquals(this.loginPage.viewError(),EMPTY_PSW_ERROR);
    }

    @Test
    public void testInvalidEmail() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.loginPage.verify();
        this.loginPage.login(emailInvalidFormat, password);

        this.loginPage.verify();
    //    Assert.assertTrue(this.loginPage.viewError().isDisplayed());
        Assert.assertEquals(this.loginPage.viewError(),INVALID_EMAIL_ERROR);
    }

    @Test
    public void testInvalidPassword() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.loginPage.verify();
        this.loginPage.login(email, pswInvalid);

        this.loginPage.verify();
      //  Assert.assertTrue(this.loginPage.viewError().isDisplayed());
        Assert.assertEquals(this.loginPage.viewError(),INVALID_CREDENTIALS_ERROR);
    }

    @Test
    public void testInvalidCredentials() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.loginPage.verify();
        this.loginPage.login(emailInvalid, pswInvalid);

        this.loginPage.verify();
     //   Assert.assertTrue(this.loginPage.viewError().isDisplayed());
        Assert.assertEquals(this.loginPage.viewError(),INVALID_CREDENTIALS_ERROR);
    }

    @Test
    public void testLogin() {
        this.dashboardPage.open();
        this.dashboardPage.verify();
        this.dashboardPage.clickLoginButton();

        this.loginPage.verify();
        this.loginPage.login(email, password);

        this.myAccountPage.verify();
    }
}
